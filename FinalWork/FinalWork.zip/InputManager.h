#pragma once

class InputManager
{
public:
	InputManager();
	~InputManager();
	static bool KEY_Q;
	static bool KEY_W;
	static bool KEY_E;
	static bool KEY_R;
	static bool KEY_T;
	static bool KEY_Y;
	static bool KEY_U;
	static bool KEY_I;
	static bool KEY_O;
	static bool KEY_P;
	static bool KEY_A;
	static bool KEY_S;
	static bool KEY_D;
	static bool KEY_F;
	static bool KEY_G;
	static bool KEY_H;
	static bool KEY_J;
	static bool KEY_K;
	static bool KEY_L;
	static bool KEY_Z;
	static bool KEY_X;
	static bool KEY_C;
	static bool KEY_V;
	static bool KEY_B;
	static bool KEY_N;
	static bool KEY_M;
	static bool KEY_1;
	static bool KEY_2;
	static bool KEY_3;
	static bool KEY_4;
	static bool KEY_5;
	static bool KEY_6;
	static bool KEY_7;
	static bool KEY_8;
	static bool KEY_9;
	static bool KEY_0;
	static bool KEY_F1;
	static bool KEY_F2;
	static bool KEY_F3;
	static bool KEY_F4;
	static bool KEY_F5;
	static bool KEY_F6;
	static bool KEY_F7;
	static bool KEY_F8;
	static bool KEY_F9;
	static bool KEY_LEFT;
	static bool KEY_RIGHT;
	static bool KEY_UP;
	static bool KEY_DOWN;
	static bool KEY_SPACE;

private:

};

