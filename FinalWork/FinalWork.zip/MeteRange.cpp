#include "MeteRange.h"

MeteRange::MeteRange()
{
}

MeteRange::~MeteRange()
{
}