#pragma once
#include "Object.h"

class EnemySpawn : public Object
{
public:
	EnemySpawn();
	~EnemySpawn();

private:

};

