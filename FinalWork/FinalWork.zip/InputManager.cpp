#include "InputManager.h"

InputManager::InputManager()
{
}

InputManager::~InputManager()
{
}

bool InputManager::KEY_Q = false;
bool InputManager::KEY_W = false;
bool InputManager::KEY_E = false;
bool InputManager::KEY_R = false;
bool InputManager::KEY_T = false;
bool InputManager::KEY_Y = false;
bool InputManager::KEY_U = false;
bool InputManager::KEY_I = false;
bool InputManager::KEY_O = false;
bool InputManager::KEY_P = false;
bool InputManager::KEY_A = false;
bool InputManager::KEY_S = false;
bool InputManager::KEY_D = false;
bool InputManager::KEY_F = false;
bool InputManager::KEY_G = false;
bool InputManager::KEY_H = false;
bool InputManager::KEY_J = false;
bool InputManager::KEY_K = false;
bool InputManager::KEY_L = false;
bool InputManager::KEY_Z = false;
bool InputManager::KEY_X = false;
bool InputManager::KEY_C = false;
bool InputManager::KEY_V = false;
bool InputManager::KEY_B = false;
bool InputManager::KEY_N = false;
bool InputManager::KEY_M = false;
bool InputManager::KEY_1 = false;
bool InputManager::KEY_2 = false;
bool InputManager::KEY_3 = false;
bool InputManager::KEY_4 = false;
bool InputManager::KEY_5 = false;
bool InputManager::KEY_6 = false;
bool InputManager::KEY_7 = false;
bool InputManager::KEY_8 = false;
bool InputManager::KEY_9 = false;
bool InputManager::KEY_0 = false;
bool InputManager::KEY_F1 = false;
bool InputManager::KEY_F2 = false;
bool InputManager::KEY_F3 = false;
bool InputManager::KEY_F4 = false;
bool InputManager::KEY_F5 = false;
bool InputManager::KEY_F6 = false;
bool InputManager::KEY_F7 = false;
bool InputManager::KEY_F8 = false;
bool InputManager::KEY_F9 = false;
bool InputManager::KEY_LEFT = false;
bool InputManager::KEY_RIGHT = false;
bool InputManager::KEY_UP = false;
bool InputManager::KEY_DOWN = false;
bool InputManager::KEY_SPACE = false;
